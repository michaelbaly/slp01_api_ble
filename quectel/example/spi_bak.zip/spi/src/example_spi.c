/******************************************************************************
*@file   example_spi.c
*@brief  example of spi operation
*           This example is used for test SPI funtion by hardware.
*           And the peripheral SPI flash type is W25Q128FV
*  ---------------------------------------------------------------------------
*
*  Copyright (c) 2018 Quectel Technologies, Inc.
*  All Rights Reserved.
*  Confidential and Proprietary - Quectel Technologies, Inc.
*  ---------------------------------------------------------------------------
*******************************************************************************/
#if defined(__EXAMPLE_SPI__)
#include "txm_module.h"
#include "qapi_diag.h"
#include "qapi_timer.h"
#include "qapi_uart.h"
#include "quectel_utils.h"
#include "quectel_uart_apis.h"
#include "qapi_fs_types.h"
#include "qapi_fs.h"
#include "qapi_atfwd.h"
#include "example_spi.h"
#include "qapi_spi_master.h"
#include "quectel_gpio.h"

#include <locale.h>

/**************************************************************************
*								  GLOBAL
***************************************************************************/
TX_BYTE_POOL *byte_pool_uart;
#define UART_BYTE_POOL_SIZE		10*8*1024
UCHAR free_memory_uart[UART_BYTE_POOL_SIZE];

/* uart2 rx tx buffer */
static char *rx2_buff=NULL;
static char *tx2_buff=NULL;
static qapi_GPIO_ID_t gpio_id_tbl[PIN_E_GPIO_MAX];
static GPIO_MAP_TBL gpio_map_tbl[PIN_E_GPIO_MAX] = {
/* PIN NUM,     PIN NAME,    GPIO ID  GPIO FUNC */
	{  4, 		"GPIO01",  		23, 	 0},
	{  5, 		"GPIO02",  		20, 	 0},
	{  6, 		"GPIO03",  		21, 	 0},
	{  7, 		"GPIO04",  		22, 	 0},
	{ 18, 		"GPIO05",  		11, 	 0},
	{ 19, 		"GPIO06",  		10, 	 0},
	{ 22, 		"GPIO07",  		 9, 	 0},
	{ 23, 		"GPIO08",  	 	 8, 	 0},
	{ 26, 		"GPIO09",  		15, 	 0},
	{ 27, 		"GPIO10",  		12, 	 0},
	{ 28, 		"GPIO11",  		13, 	 0},
	{ 40, 		"GPIO19",  		19, 	 0},
	{ 41, 		"GPIO20",  		18, 	 0},
	{ 64, 		"GPIO21",  		07, 	 0},
};

/* uart config para*/
static QT_UART_CONF_PARA uart2_conf =
{
	NULL,
	QT_UART_PORT_03,
	NULL,
	0,
	NULL,
	0,
	115200
};

qapi_SPIM_Config_t spi_config; // for spi config
void *spi_hdl = NULL;

/*spi callback func*/
int cb_para = 0;


/**************************************************************************
*                                 FUNCTION
***************************************************************************/
static void atel_dbg_print(const char* fmt, ...)
{
	char log_buf[256] = {0};

	va_list ap;
	va_start(ap, fmt);
	vsnprintf(log_buf, sizeof(log_buf), fmt, ap);
	va_end(ap);

	qapi_atfwd_send_urc_resp("ATEL", log_buf);
	//qapi_Timer_Sleep(50, QAPI_TIMER_UNIT_MSEC, true);

	return;
}
#if 0
static void gpio_dir_control(MODULE_PIN_ENUM pin_num, qapi_GPIO_Direction_t direction)
{
	gpio_config(pin_num, direction, QAPI_GPIO_NO_PULL_E, QAPI_GPIO_2MA_E);	
}

static void gpio_value_control(MODULE_PIN_ENUM pin_num, boolean vaule)
{

	if(vaule)
		qapi_TLMM_Drive_Gpio(gpio_id_tbl[pin_num], gpio_map_tbl[pin_num].gpio_id, QAPI_GPIO_HIGH_VALUE_E);
	else
		qapi_TLMM_Drive_Gpio(gpio_id_tbl[pin_num], gpio_map_tbl[pin_num].gpio_id, QAPI_GPIO_LOW_VALUE_E);
}
#endif
void qapi_spi_cb_func(uint32 status, void *cb_para)
{
    if (QAPI_SPI_COMPLETE == status)
    {//The transaction is complete.
        atel_dbg_print("[==spim_cb_func==]: transfer success, status: %d, cb_p: %d", status, *((int*)cb_para));
	}
    else if (QAPI_SPI_QUEUED == status || QAPI_SPI_IN_PROGRESS == status)
    {//The transaction is processing.
        atel_dbg_print("[==spim_cb_func==]: transfer in progress, status: %d, cb_p: %d", status, *((int*)cb_para));
    }
    else
    {//An error occured in the transaction.
        atel_dbg_print("[==spim_cb_func==]: transfer failed, status: %d, cb_p: %d", status, *((int*)cb_para));
    }
}
UCHAR readDataBytes(UINT addr)
{
	qapi_Status_t ret = QAPI_OK; 

	UCHAR tx_buf[4]={0xFF, 0xFF, 0xFF, 0xFF};
	UCHAR rx_buf[100]={0xFF};
	memset(rx_buf, 0xFE, 100);
	qapi_SPIM_Descriptor_t spi_desc[1];
	
	tx_buf[0] = 0x03;
	tx_buf[1] = (addr>>16)&0xFF;
	tx_buf[2] = (addr >>8)&0xFF;
	tx_buf[3] = (addr >>0)&0xFF;
	
    spi_desc[0].tx_buf = tx_buf;
	spi_desc[0].rx_buf = rx_buf;
    spi_desc[0].len = 4;
    cb_para = CP_PARAM_RD;
    
    ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor
    qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
    //atel_dbg_print("[readDataBytes] ret=%x,rx[0]=%x, rx[1]=%x, rx[2]=%x, rx[3]=%x\r\n", ret, rx_buf[0], rx_buf[1], rx_buf[2], rx_buf[3]);
	int i=0;
	for(;i<20;i++)
	{
		
			atel_dbg_print("%x\r\n", rx_buf[i]);
	}
	return ret;		
}
UCHAR readRegStat()
{
	qapi_Status_t ret = QAPI_OK; 
	UCHAR tx_buf[1]={0xFF};
	UCHAR rx_buf[10]={0xFF};
	qapi_SPIM_Descriptor_t spi_desc[1];
	memset(rx_buf, 0xFF, 10);
	tx_buf[0] = 0x05;
    spi_desc[0].tx_buf = tx_buf;
	spi_desc[0].rx_buf = rx_buf;
    spi_desc[0].len = 1;
    cb_para = CP_PARAM_RD_REG_STATUS;
    
    ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false);
    qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
    atel_dbg_print("[readRegStat] ret=%x\r\n", ret);

	int i;
	for(;i<10;i++)
	{
		atel_dbg_print("%x\r\n", rx_buf[i]);;
	}
		
	
    return ret;		
}

UCHAR chipErase()
{
	qapi_Status_t ret = QAPI_OK; 
	UCHAR tx_buf[1]={0xFF};
	UCHAR rx_buf[1]={0xFF};
	qapi_SPIM_Descriptor_t spi_desc[1];

	tx_buf[0] = CHIP_ERASE_CMD;
    spi_desc[0].tx_buf = tx_buf;
	spi_desc[0].rx_buf = rx_buf;
    spi_desc[0].len = 1;
    cb_para = CP_PARAM_CHIP_ERASE;
    
    ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false);
    qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
    atel_dbg_print("[chipErase] ret=%x\r\n", ret);
    return ret;		

}

UCHAR writeEnable()
{
	qapi_Status_t ret = QAPI_OK; 
	UCHAR tx_buf[4]={0xFF,0xFF,0xFF,0xFF};
	UCHAR rx_buf[4]={0xFF};
	qapi_SPIM_Descriptor_t spi_desc[1];

	tx_buf[0] = WR_EN_CMD;
    spi_desc[0].tx_buf = tx_buf;
	spi_desc[0].rx_buf = rx_buf;
    spi_desc[0].len = 4;
    cb_para = CP_PARAM_WR_EN;
    
    ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false);
    qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
    atel_dbg_print("[writeEnable] ret=%x\r\n", ret);
    return ret;		
}
UCHAR writeDisable()
{

	qapi_Status_t ret = QAPI_OK; 
	UCHAR tx_buf[4]={0xFF,0xFF,0xFF,0xFF};
	UCHAR rx_buf[4]={0xFF};
	qapi_SPIM_Descriptor_t spi_desc[1];

	tx_buf[0] = WR_DISEN_CMD;
    spi_desc[0].tx_buf = tx_buf;
	spi_desc[0].rx_buf = rx_buf;
    spi_desc[0].len = 4;
    cb_para = CP_PARAM_WR_DIS_EN;
    
    ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor
    qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
    atel_dbg_print("[writeDisable] ret=%x\r\n", ret);
    return ret;		
}
UCHAR sectorErase(UINT addr)
{
		qapi_Status_t ret = QAPI_OK; 
		UCHAR tx_buf[4]={0xFF, 0xFF, 0xFF, 0xFF};
		UCHAR rx_buf[4]={0xFF, 0xFF, 0xFF, 0xFF};
		qapi_SPIM_Descriptor_t spi_desc[1];
		
		tx_buf[0] = 0x20;
		tx_buf[1] = (addr>>16)&0xFF;
		tx_buf[2] = (addr >>8)&0xFF;
		tx_buf[3] = (addr >>0)&0xFF;
		
		spi_desc[0].tx_buf = tx_buf;
		spi_desc[0].rx_buf = rx_buf;
		spi_desc[0].len = 4;
		cb_para = CP_PARAM_SEC_ERS;
		
		ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor
		qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
		atel_dbg_print("[sectorErase] ret=%x,rx[0]=%x, rx[1]=%x, rx[2]=%x, rx[3]=%x\r\n", ret, rx_buf[0], rx_buf[1], rx_buf[2], rx_buf[3]);
		
		return ret; 	
}

UCHAR writeByte(UINT addr)
{
		qapi_Status_t ret = QAPI_OK; 
		
		UCHAR tx_buf[260]={0};
		UCHAR rx_buf[260]={0};
		
		qapi_SPIM_Descriptor_t spi_desc[1];
		
		memset(tx_buf, 0x33, 260);
		memset(rx_buf, 0x22, 260);
		
		tx_buf[0] = WR_BYTE_CMD;
		tx_buf[1] = (addr>>16)&0xFF;
		tx_buf[2] = (addr >>8)&0xFF;
		tx_buf[3] = (addr >>0)&0xFF;
		
		spi_desc[0].tx_buf = tx_buf;
		spi_desc[0].rx_buf = rx_buf;
		spi_desc[0].len = 260;
		cb_para = CP_PARAM_WR;

		//qapi_Timer_Sleep(1000, QAPI_TIMER_UNIT_MSEC, true);
#if 1	
		//writeEnable();
		ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor
		qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
		atel_dbg_print("[writeByte] ret=%x,rx[0]=%x, rx[1]=%x, rx[2]=%x, rx[3]=%x, rx[4]=%x\r\n", ret, rx_buf[0], rx_buf[1], rx_buf[2], rx_buf[3], rx_buf[4]);
		//writeDisable();

		//writeDisable();
#endif
		return ret; 

}
#define RD_LEN 6
UCHAR readMid()
{
		qapi_Status_t ret = QAPI_OK; 
		
		UCHAR tx_buf[RD_LEN]={0};
		UCHAR rx_buf[RD_LEN]={0};
		
		qapi_SPIM_Descriptor_t spi_desc[1];
		
		memset(tx_buf, 0xFF, RD_LEN);
		memset(rx_buf, 0xFF, RD_LEN);
		//02FFFF
		tx_buf[0] = 0x90;
		tx_buf[1] = 0xFF;
		tx_buf[2] = 0xFF;
		tx_buf[3] = 0x00;
		
		spi_desc[0].tx_buf = tx_buf;
		spi_desc[0].rx_buf = rx_buf;
		spi_desc[0].len = RD_LEN;
		cb_para = 2;

		qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
#if 1		
		ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor
		qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
		atel_dbg_print("[readMid] ret=%x,rx[0]=%x, rx[1]=%x, rx[2]=%x, rx[3]=%x, rx[4]=%x, rx[5]=%x\r\n", ret, rx_buf[0], rx_buf[1], rx_buf[2], rx_buf[3], rx_buf[4], rx_buf[5]);

		//writeDisable();
#endif
		return ret; 	
}

#define RD_NM_LEN 30
UCHAR readNormal()
{
		qapi_Status_t ret = QAPI_OK; 
		
		UCHAR tx_buf[RD_NM_LEN]={0};
		UCHAR rx_buf[RD_NM_LEN]={0};
		
		qapi_SPIM_Descriptor_t spi_desc[1];
		
		memset(tx_buf, 0xFF, RD_NM_LEN);
		memset(rx_buf, 0xFF, RD_NM_LEN);
		//02FFFF
		tx_buf[0] = 0x03;
		tx_buf[1] = 0x02;
		tx_buf[2] = 0x00;
		tx_buf[3] = 0x00;
		
		spi_desc[0].tx_buf = tx_buf;
		spi_desc[0].rx_buf = rx_buf;
		spi_desc[0].len = 4;
		cb_para = 3;

		qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
#if 1		
		ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor

		qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
		
		atel_dbg_print("[readNormal] ret:%d\r\n", ret);
		int i=0;
		for(;i<RD_NM_LEN;i++)
		{
			
			atel_dbg_print("%x\r\n", rx_buf[i]);
		}
		
		//writeDisable();
#endif
		return ret; 	
}


int quectel_task_entry(void)
{
    qapi_Status_t ret = QAPI_OK; 
    uint8 wr_buff[4] = {0x9f, 0xff, 0xff, 0xff}; // cmd for read flash id
    uint8 rd_buff[4] = {0xff, 0xff, 0xff, 0xff}; // buff for id
    qapi_SPIM_Descriptor_t spi_desc[1];

	setlocale(LC_ALL, "C");	/// <locale.h>

    qapi_Timer_Sleep(3000, QAPI_TIMER_UNIT_MSEC, true);

	IOT_DEBUG("QT# quectel_task_entry Start");

	ret = txm_module_object_allocate(&byte_pool_uart, sizeof(TX_BYTE_POOL));
  	if(ret != TX_SUCCESS)
  	{
  		IOT_DEBUG("txm_module_object_allocate [byte_pool_sensor] failed, %d", ret);
    	return ret;
  	}

	ret = tx_byte_pool_create(byte_pool_uart, "Sensor application pool", free_memory_uart, UART_BYTE_POOL_SIZE);
  	if(ret != TX_SUCCESS)
  	{
  		IOT_DEBUG("tx_byte_pool_create [byte_pool_sensor] failed, %d", ret);
    	return ret;
  	}

  /*QT_UART_ENABLE_2ND */ 
	ret = tx_byte_allocate(byte_pool_uart, (VOID *)&rx2_buff, 4*1024, TX_NO_WAIT);
  	if(ret != TX_SUCCESS)
  	{
  		IOT_DEBUG("tx_byte_allocate [rx2_buff] failed, %d", ret);
    	return ret;
  	}

  	ret = tx_byte_allocate(byte_pool_uart, (VOID *)&tx2_buff, 4*1024, TX_NO_WAIT);
  	if(ret != TX_SUCCESS)
  	{
  		IOT_DEBUG("tx_byte_allocate [tx2_buff] failed, %d", ret);
    	return ret;
  	}

	/* uart 2 init */
	uart_init(&uart2_conf);
	/* start uart 2 receive */
	uart_recv(&uart2_conf);
	/* prompt task running */
	//qt_uart_dbg(uart2_conf.hdlr, "\r\n===quectel spi task entry Start!!!===\r\n");
	
	atel_dbg_print("\r\n===quectel spi task entry Start!!!===\r\n");

    // Obtain a client specific connection handle to the spi bus instance 6
    ret = qapi_SPIM_Open(QAPI_SPIM_INSTANCE_6_E, &spi_hdl);    
    atel_dbg_print("qapi_SPIM_Open: res=%d, hdl=%x", ret, spi_hdl);

    ret = qapi_SPIM_Power_On(spi_hdl);
    atel_dbg_print("qapi_SPIM_Power_On: res=%d", ret);

    //spi interface config
    spi_config.SPIM_Mode = QAPI_SPIM_MODE_0_E; // set the spi mode, determined by slave device
    spi_config.SPIM_CS_Polarity = QAPI_SPIM_CS_ACTIVE_LOW_E; // set CS low as active, determined by slave device
    spi_config.SPIM_endianness  = SPI_LITTLE_ENDIAN;
    spi_config.SPIM_Bits_Per_Word = 8;
    spi_config.SPIM_Slave_Index = 0;
    spi_config.Clk_Freq_Hz = 1000000; //config spi clk about 1Mhz
    spi_config.SPIM_CS_Mode = QAPI_SPIM_CS_KEEP_ASSERTED_E;
    spi_config.CS_Clk_Delay_Cycles = 0; // don't care, set 0 is ok.
    spi_config.Inter_Word_Delay_Cycles = 0; // don't care, set 0 is ok.
    spi_config.loopback_Mode = 0;
    
    
    atel_dbg_print("[config] MDOE=%d, Clk_Freq_Hz=%d, Bits_Per_Word=%d\r\n", spi_config.SPIM_Mode, spi_config.Clk_Freq_Hz, spi_config.SPIM_Bits_Per_Word);   
    
    
    spi_desc[0].tx_buf = wr_buff;
	spi_desc[0].rx_buf = rd_buff;
    spi_desc[0].len = 4;
    cb_para = 1;
    
    ret = qapi_SPIM_Full_Duplex(spi_hdl, &spi_config, spi_desc, 1, qapi_spi_cb_func, &cb_para, false); // at now only support one descriptor
    qapi_Timer_Sleep(1000, QAPI_TIMER_UNIT_MSEC, true);
    atel_dbg_print("[Read flash ID] ret=%x, rd[1]=%x, rd[2]=%x, rd[3]=%x\r\n", ret, rd_buff[1], rd_buff[2], rd_buff[3]);
	

#if 0
	
	qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
	chipErase();
	qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
#endif
#if 1
	readMid();
	qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
	//readNormal();
	//readDataBytes(0x00020000);
#endif	


#if 1
	UINT addr = 0x00010000;
	

	//readDataBytes(addr);
	qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);

	writeEnable();
	//sectorErase(addr);
	chipErase();
	writeDisable();
	readRegStat();
	qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
	writeEnable();
	readRegStat();
	writeByte(addr);
	writeDisable();
	qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
	
	//qapi_Timer_Sleep(1000, QAPI_TIMER_UNIT_MSEC, true);
	//readRegStat();
	readDataBytes(addr);
#endif 	


    ret = qapi_SPIM_Power_Off(spi_hdl);
    atel_dbg_print("qapi_SPIM_Power_Off: ret=%d", ret);

    // Close the connection handle to the spi bus instance
    ret = qapi_SPIM_Close(spi_hdl);    
    qapi_Timer_Sleep(500, QAPI_TIMER_UNIT_MSEC, true);
    atel_dbg_print("qapi_SPIM_Close: ret=%d", ret);

	atel_dbg_print("\r\n===quectel spi task entry Exit!!!===\r\n");
    return 0;
}

#endif /*__EXAMPLE_SPI__*/

